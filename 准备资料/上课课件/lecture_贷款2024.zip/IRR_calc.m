clc,clear all;
A0=1000; %贷款额;
a0=210; %"砍头息";
a1=379.65;
a2=340.02;
a3=340.02;
n=12; % T = 1/4; nT=3;
% y = 1/(1+r)^(1/n);
fun = @(y) -(A0-a0)+a1*y+a2*y.^2+a3*y.^3;
range = [0.7,0.9];
fplot(fun,range)
y=fzero(fun,range)
r=(1/y)^n-1