clear all; clc
A0 = 220000;
x = 2338;
N = 120;  % 10�ꣻ

f1  = @(r) A0*(1+r).^(N+1) - (A0+x)*(1+r).^N + x;
f2  = @(r) 0*r;
%xspan = [0,0.02];
xspan = [0.0042,0.00421];
grid
fplot(f1, xspan,'b')
hold on
fplot(f2, xspan,'r')
hold off

pause

r0=fzero(f1, xspan)
r1=fzero(inline('220000*(1+r)^121-222338*(1+r)^120+2338'), xspan)
r2=fzero(@(r)(220000*(1+r)^121-222338*(1+r)^120+2338), xspan)

% Instead of "fzero", can also use "fsolve" function to find the solution